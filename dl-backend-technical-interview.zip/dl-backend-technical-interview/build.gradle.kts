val versionKotlin: String by project
val versionKtor: String by project
val versionLogback: String by project
val versionApp: String by project
val versionGson: String by project
val versionCucumber: String by project
val versionHttpClient: String by project
val versionCommonsIo: String by project
val versionJunit: String by project
val versionMockito: String by project

// Note: The `plugins` block is the newer method of applying plugins, but in order to be able to add a plugin
// via this mechanism they must be available on the Gradle Plugin Repository: http://plugins.gradle.org/
// where possible, plugins should be added via this section
plugins {
    application
    kotlin("jvm") version "1.4.10"
}

group = "com.technical"
version = versionApp
application {
    mainClassName = "io.ktor.server.jetty.EngineMain"
}

repositories {
    jcenter()
}

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8:$versionKotlin")

    implementation("io.ktor:ktor-server-jetty:$versionKtor")
    implementation("ch.qos.logback:logback-classic:$versionLogback")

    implementation("com.google.code.gson:gson:$versionGson")
    implementation("commons-io:commons-io:$versionCommonsIo")
    implementation("org.apache.httpcomponents:httpclient:$versionHttpClient")

    // issuing our own JWT tokens
    implementation("io.ktor:ktor-auth:$versionKtor")
    implementation("io.ktor:ktor-auth-jwt:$versionKtor")

    testImplementation("io.ktor:ktor-server-tests:$versionKtor")
    testImplementation("io.cucumber:cucumber-java:$versionCucumber")
    testImplementation("junit:junit:$versionJunit")
    testImplementation("org.mockito:mockito-core:$versionMockito")
}

kotlin.sourceSets["main"].kotlin.srcDirs("src")
kotlin.sourceSets["test"].kotlin.srcDirs("test")

sourceSets["main"].java.srcDirs("src")
sourceSets["main"].resources.srcDirs("resources")
sourceSets["test"].java.srcDirs("test/src/java")

val cucumberRuntime by configurations.creating {
    extendsFrom(configurations["testImplementation"])
}

task("cucumber") {
    dependsOn("assemble", "testClasses")
    doLast {
        javaexec {
            main = "io.cucumber.core.cli.Main"
            classpath = cucumberRuntime + sourceSets.main.get().output + sourceSets.test.get().output
            args = listOf(
                "--plugin", "pretty",
                "--plugin", "html:target/cucumber-report.html",
                "--glue", "bdd",
                "test/src/resources")
        }
    }
}