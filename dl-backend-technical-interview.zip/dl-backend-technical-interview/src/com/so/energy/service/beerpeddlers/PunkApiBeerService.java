package com.so.energy.service.beerpeddlers;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.so.energy.domain.Beer;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class PunkApiBeerService implements BeerService {

    private static final Logger log = LoggerFactory.getLogger(PunkApiBeerService.class);

    private static final String ROOT_ENDPOINT = "https://api.punkapi.com/v2/beers/";

    @Override
    public List<Beer> getAllBeers() {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpGet httpget = new HttpGet(ROOT_ENDPOINT);
            CloseableHttpResponse response = httpclient.execute(httpget);

            return new Gson().fromJson(EntityUtils.toString(response.getEntity()), new TypeToken<List<Beer>>() {
            }.getType());
        } catch (IOException ioe) {
            log.error("Failed to retrieve beers from PunkAPI: {}", ioe.getMessage(), ioe);
            return Collections.emptyList();
        }
    }

}
