package com.so.energy.service.beerpeddlers;

import com.so.energy.domain.Beer;

import java.util.List;

public interface BeerService {

    List<Beer> getAllBeers();

}
