package com.so.energy.service.beerpeddlers;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.so.energy.domain.Beer;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.List;

public class LocallySourcedBeersService implements BeerService {

    private static final Logger log = LoggerFactory.getLogger(LocallySourcedBeersService.class);

    @Override
    public List<Beer> getAllBeers() {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("so-energy-beers.json")) {
            String rawJson = IOUtils.toString(is, Charset.defaultCharset());
            return new Gson().fromJson(rawJson, new TypeToken<List<Beer>>() {
            }.getType());
        } catch (IOException ioe) {
            log.error("Failed to read locally sourced beers: {}", ioe.getMessage(), ioe);
            return Collections.emptyList();
        }
    }

}
