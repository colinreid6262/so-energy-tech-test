package com.so.energy.service;

import com.so.energy.domain.Beer;
import com.so.energy.service.beerpeddlers.BeerService;
import com.so.energy.service.beerpeddlers.LocallySourcedBeersService;
import com.so.energy.service.beerpeddlers.PunkApiBeerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class ConsolidatedBeerService {

    private static final Logger log = LoggerFactory.getLogger(ConsolidatedBeerService.class);

    private List<BeerService> beersPeddlers;
    private Map<Integer, Beer> allBeers;

    public ConsolidatedBeerService() {
        // Note - would normally utilise a DI framework such as Spring or Guice to inject the beerPeddlers
        // but this would be overkill for the purposes of this small exercise
        setBeersPeddlers(List.of(new LocallySourcedBeersService(), new PunkApiBeerService()));
    }

    public ConsolidatedBeerService initialise() {
        allBeers = new HashMap<>();
        int pseudoId = 1;
        for (BeerService beerService : beersPeddlers) {
            for (Beer beer : beerService.getAllBeers()) {
                beer.setIdentifier(pseudoId);
                allBeers.put(pseudoId++, beer);
            }
        }
        return this;
    }

    // To assist with unit testing, package private to limit scope. Would normally use ctor dependency injection
    void setBeersPeddlers(List<BeerService> beersPeddlers) {
        this.beersPeddlers = beersPeddlers;
    }

    public Beer[] getAllBeers() {
        return allBeers.values().toArray(new Beer[]{});
    }

    public Beer getBeer(int id) {
        return allBeers.get(id);
    }

    public Beer[] searchBeers(String searchTerm) {
        return allBeers.values().parallelStream()
                .filter(beer -> beer.getName().equals(searchTerm)).toArray(Beer[]::new);
    }

    public void addBeer(Beer beer) {
        beer.setIdentifier(allBeers.size() + 1);
        allBeers.put(beer.getIdentifier(), beer);
    }

    public Optional<Beer> getRandomBeer() {
        return allBeers.values().parallelStream().findAny();
    }

}
