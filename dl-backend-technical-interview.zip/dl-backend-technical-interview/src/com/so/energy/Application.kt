package com.so.energy

import com.google.gson.Gson
import com.so.energy.domain.Beer
import com.so.energy.service.ConsolidatedBeerService
import io.ktor.application.*
import io.ktor.http.*
import io.ktor.request.*
import io.ktor.response.*
import io.ktor.routing.get
import io.ktor.routing.post
import io.ktor.routing.routing
import org.slf4j.Logger
import org.slf4j.LoggerFactory

val logger: Logger = LoggerFactory.getLogger(Application::class.java)

fun main(args: Array<String>) {
    io.ktor.server.jetty.EngineMain.main(args)
}

// Referenced in application.conf
@Suppress("unused")
@kotlin.jvm.JvmOverloads
fun Application.module(testing: Boolean = false) {

    var beerSvc = ConsolidatedBeerService().initialise()
    var gson = Gson() // Thread safe

    routing {
        get("/health-check") {
            logger.debug("healthy")
            call.respondText("healthy", contentType = ContentType.Text.Plain)
        }
        // Get a beer for a given ID
        get("/beers/{id}") {
            val id = call.parameters["id"]?.toInt()
            var jsonResponse = ""
            if (id == null) {
                jsonResponse = errorMsg()
            } else {
                jsonResponse = gson.toJson(beerSvc.getBeer(id))
            }
            call.respondText(jsonResponse, contentType = ContentType.Application.Json)
        }
        // Get all beers and search all beers for a given name
        get("beers") {
            val searchTerm = call.request.queryParameters["name"]
            var jsonResponse = ""
            if (searchTerm == null) {
                jsonResponse = gson.toJson(beerSvc.getAllBeers())
            } else {
                jsonResponse = gson.toJson(beerSvc.searchBeers(searchTerm))
            }
            call.respondText(jsonResponse, contentType = ContentType.Application.Json)
        }
        // Get a random beer
        get("beers/random") {
            val jsonResponse = gson.toJson(beerSvc.getRandomBeer())
            call.respondText(jsonResponse, contentType = ContentType.Application.Json)
        }
        // Add a beer
        post("beers") {
            val json = call.receiveText()
            beerSvc.addBeer(gson.fromJson(json, Beer::class.java))
        }
    }
}

fun errorMsg(): String {
    return "{\"msg:\":\"Invalid input\"}"
}