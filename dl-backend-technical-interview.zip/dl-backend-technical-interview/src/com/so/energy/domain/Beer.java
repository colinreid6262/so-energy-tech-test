package com.so.energy.domain;

import com.google.gson.annotations.SerializedName;

public class Beer {

    @SerializedName(value = "identifier", alternate = {"beer_identifier", "id"})
    private int identifier;

    @SerializedName(value = "name", alternate = "beer_name")
    private String name;

    @SerializedName(value = "description", alternate = "beer_description")
    private String description;

    public Beer() {
    }

    public Beer(int identifier, String name, String description) {
        this.identifier = identifier;
        this.name = name;
        this.description = description;
    }

    public int getIdentifier() {
        return identifier;
    }

    public void setIdentifier(int identifier) {
        this.identifier = identifier;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
