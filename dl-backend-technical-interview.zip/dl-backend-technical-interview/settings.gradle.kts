rootProject.name = "dl-backend-technical-interview"
