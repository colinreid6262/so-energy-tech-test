package com.so.energy.service.beerpeddlers;


import com.so.energy.domain.Beer;
import org.junit.Test;

import java.util.List;

import static junit.framework.TestCase.assertEquals;

public class LocallySourcedBeersServiceTest {

    @Test
    public void getAllBeers() {
        LocallySourcedBeersService locallySourcedBeersService = new LocallySourcedBeersService();
        List<Beer> allBeers = locallySourcedBeersService.getAllBeers();
        assertEquals(2, allBeers.size());
    }

}