package com.so.energy.service;

import com.so.energy.domain.Beer;
import com.so.energy.service.beerpeddlers.BeerService;
import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.Optional;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ConsolidatedBeerServiceTest {

    ConsolidatedBeerService target;

    @Before
    public void setup() {
        target = new ConsolidatedBeerService();
        BeerService mock = mock(BeerService.class);
        when(mock.getAllBeers()).thenReturn(List.of(
                new Beer(1, "tennents", "light"),
                new Beer(2, "punkipa", "medium"),
                new Beer(3, "heineken", "heavy")));
        target.setBeersPeddlers(List.of(mock));
        target.initialise();
    }

    @Test
    public void getBeer() {
        assertEquals("punkipa", target.getBeer(2).getName());
    }

    @Test
    public void getAllBeers() {
        assertEquals(3, target.getAllBeers().length);
    }

    @Test
    public void searchBeers(){
        Beer[] beers = target.searchBeers("punkipa");
        assertEquals(1, beers.length);
        assertEquals("punkipa", beers[0].getName());
    }

    @Test
    public void getRandomBeer(){
        Optional<Beer> randomBeer = target.getRandomBeer();
        assertTrue(randomBeer.isPresent());
    }

    @Test
    public void addBeer(){
        target.addBeer(new Beer());
        assertEquals(4, target.getAllBeers().length);
    }

}