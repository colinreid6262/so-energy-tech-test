package bdd;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.so.energy.domain.Beer;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.*;

public class StepDefs {

    private static final Logger log = LoggerFactory.getLogger(StepDefs.class);

    private int lastStatusCode;
    private Beer lastBeer;
    private List<Beer> lastBeers;

    @When("the healthcheck endpoint is called")
    public void theHealthcheckEndpointIsCalled() {
        httpGETRequest("http://localhost:8080/health-check", false, false);
    }

    @Then("there is an http response code of {int}")
    public void thereIsAnHttpResponseCodeOf(int responseCode) {
        assertEquals(lastStatusCode, responseCode);
    }

    @Given("a beer with id {int} is present in the catalogue")
    public void aBeerWithIdIsPresentInTheCatalogue(int beerId) {
        // Assume for this exercise that the Given case is true
    }

    @When("a request is made to retrieve beer with id {int}")
    public void aRequestIsMadeToRetrieveBeerWithId(int beerId) {
        httpGETRequest("http://localhost:8080/beers/" + beerId, true, false);
    }

    @Then("the service replies with beer with id {int}")
    public void theServiceRepliesWithBeerWithId(int beerId) {
        try {
            assertNotNull(lastBeer);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Given("at least two beers exist in the catalogue")
    public void atLeastTwoBeersExistsInTheCatalogue() {
        // Assume for this exercise that the Given case is true
    }

    @When("a request is made to retrieve all beers")
    public void aRequestIsMadeToRetrieveAllBeers() {
        httpGETRequest("http://localhost:8080/beers", true, true);
    }

    @Then("the service replies with all beers")
    public void theServiceRepliesWithAllBeers() {
        assertFalse(lastBeers.isEmpty());
    }

    @Given("a beer with name Movember is present in the catalogue")
    public void aBeerWithMnameTennentsIsPresentInTheCatalogue() {
        // Assume for this exercise that the Given case is true
    }

    @When("a request is made for beer with name Movember")
    public void aRequestIsMadeForBeerWithName() {
        httpGETRequest("http://localhost:8080/beers?name=Movember", true, true);
    }

    @Then("the service replies with beer with name Movember")
    public void theServiceRepliesWithBeerWithName() {
        assertEquals(1, lastBeers.size());
        assertEquals("Movember", lastBeers.get(0).getName());
    }

    @When("a request is made for a random beer")
    public void aRequestIsMadeForARandomBeer() {
        httpGETRequest("http://localhost:8080/beers/random", true, false);
    }

    @Then("the service replies with a random beer")
    public void theServiceRepliesWithARandomBeer() {
        assertNotNull(lastBeer);
    }

    @When("a request is made to add a beer")
    public void aRequestIsMadeToAddABeer() {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            lastBeer = new Beer();
            lastBeer.setName("PunkIPA");

            HttpPost httppost = new HttpPost("http://localhost:8080/beers");
            String jsonStr = new Gson().toJson(lastBeer);
            StringEntity requestEntity = new StringEntity(
                    jsonStr, ContentType.APPLICATION_JSON);
            httppost.setEntity(requestEntity);

            lastStatusCode = httpclient.execute(httppost).getStatusLine().getStatusCode();
        } catch (IOException ioe) {
            fail(ioe.getMessage());
        }
    }

    @Then("the new beer is added to the catalogue")
    public void theNewBeerIsAddedToTheCatalogue() {
        String newName = lastBeer.getName();
        try {
            httpGETRequest("http://localhost:8080/beers?name=" + lastBeer.getName(), true, true);
            assertEquals(1, lastBeers.size());
            assertEquals(newName, lastBeers.get(0).getName());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    private void httpGETRequest(String url, boolean producesBeer, boolean multipleBeers) {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpGet httpget = new HttpGet(url);
            CloseableHttpResponse response = httpclient.execute(httpget);
            lastStatusCode = response.getStatusLine().getStatusCode();
            if (producesBeer) {
                if (multipleBeers) {
                    lastBeers = new Gson().fromJson(EntityUtils.toString(response.getEntity()), new TypeToken<List<Beer>>() {
                    }.getType());
                } else {
                    lastBeer = new Gson().fromJson(EntityUtils.toString(response.getEntity()), Beer.class);
                }
            }
        } catch (IOException ioe) {
            fail(ioe.getMessage());
        }
    }

}
